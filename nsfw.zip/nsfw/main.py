import app_nsfw
from app_nsfw import app

if __name__ == "__main__":
    app.run()
"""
from flask import Flask
from app_nsfw import nsfw_core as nsfw
from app_nsfw import methods
from datetime import datetime
from time import strftime



print("version: " + str(nsfw.version()))

# nsfw.init('deploy.prototxt', 'resnet_50_1by2_nsfw.caffemodel')
#nsfw.init('./config/deploy.prototxt', './config/resnet_50_1by2_nsfw.caffemodel')
print(nsfw.predict('./files/esabil/08172018/lowneck1.jpg'))

print("Library Initialized:" + __name__)
stime=datetime.now().strftime('%4Y%2m%2d%2H%2M%2S')
print(stime)
#print(strftime('%4Y%2m%2d%2H%2M%2S',datetime.now()))


#    app_nsfw.run(host='0.0.0.0')
"""
