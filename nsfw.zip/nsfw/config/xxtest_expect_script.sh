#!/bin/bash
echo "esabil bulbul"
set timeout 1
#spawn ./interactive_program.sh
#spawn apt -y install caffe
apt-get install vim
#expect -exact "what is your name?"
#send -- "Sam\r"
#expect -exact "how many dogs?"
#send -- "2\r"

CMD [ "echo", "ok" ]