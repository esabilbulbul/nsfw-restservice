#!/bin/bash
echo "initializing"
ln -s /usr/src/app/config/nsfw_nginx.conf /etc/nginx/conf.d/
