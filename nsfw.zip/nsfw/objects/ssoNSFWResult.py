
class NSFWResult:
    start_time = 0
    end_time = 0
    score = 0

