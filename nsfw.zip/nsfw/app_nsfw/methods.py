from flask import request, jsonify, json
from app_nsfw import nsfw_core as nsfw
from app_nsfw import app  #imports (app) variable
import os
from datetime import datetime
import socket
from time import gmtime, strftime

#from objects import ssoNSFWResult as NSFWObj

ROOT_PATH = '/usr/src/app/rep'
#ROOT_PATH = './files'

@app.route('/')
@app.route('/index')
def index():
    return "test"

#
# Sample URL  http://127.0.0.1:5000/predict/esabil/08172018?f=lowneck1.jpg
#
@app.route('/predict/<p_userid>/<p_datetime>', methods=['GET'])
def predict(p_userid, p_datetime):

    dt_startdatetime = datetime.now()
    s_startdatetime  = dt_startdatetime.strftime('%4Y%2m%2d%2H%2M%2S%f')[:-3]

    filename = request.args.get('f')
    filepath = ROOT_PATH + '/' + p_userid + '/' + p_datetime + '/' + filename

    dirpath = os.getcwd()
    print('dirpath= ' + dirpath)

    #result = NSFWObj.NSFWResult() #this won't be used only for test purpose
    #result.end_time = 1

    score = nsfw.predict(filepath)
    dt_enddatetime = datetime.now()
    s_enddatetime  = dt_enddatetime.strftime('%4Y%2m%2d%2H%2M%2S%f')[:-3]

    #hip = socket.gethostbyname("www.goole.com") #to get ipaddr
    result = {'starttime':1, 'endtime':2, 'score': score, 'starttime': s_startdatetime, 'endtime': s_enddatetime}

    return json.dumps(result)


print('!!! methods loaded !!!')