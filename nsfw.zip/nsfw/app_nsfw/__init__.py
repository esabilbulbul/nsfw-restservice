from flask import Flask

app = Flask(__name__)

# from app_nsfw import routes
from app_nsfw import methods

print('!!! __init__.py loaded !!!')
print('!!! name: ' + __name__)

if __name__ == "main":
    app.run()